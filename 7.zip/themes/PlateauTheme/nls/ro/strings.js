﻿/*global define*/
define({
  "_themeLabel": "Temă platou",
  "_layout_default": "Configuraţie implicită",
  "_layout_layout1": "Aspectul 1"
});