﻿/*global define*/
define({
  "_themeLabel": "Plynaukštės tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_layout1": "1 maketas"
});