﻿/*global define*/
define({
  "_themeLabel": "نُسُق الجدول",
  "_layout_default": "تخطيط افتراضي",
  "_layout_layout1": "تخطيط 1"
});