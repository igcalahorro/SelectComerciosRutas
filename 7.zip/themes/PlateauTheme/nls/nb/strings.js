﻿/*global define*/
define({
  "_themeLabel": "Platå-tema",
  "_layout_default": "Standardoppsett",
  "_layout_layout1": "Oppsett 1"
});