﻿/*global define*/
define({
  "_themeLabel": "Tema platoa",
  "_layout_default": "Zadani izgled",
  "_layout_layout1": "Izgled 1"
});