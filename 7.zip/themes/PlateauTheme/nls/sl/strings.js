﻿/*global define*/
define({
  "_themeLabel": "Plato",
  "_layout_default": "Privzeta postavitev",
  "_layout_layout1": "Postavitev 1"
});