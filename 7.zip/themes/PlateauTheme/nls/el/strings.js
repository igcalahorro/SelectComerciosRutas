﻿/*global define*/
define({
  "_themeLabel": "Θέμα σταθερού επιπέδου",
  "_layout_default": "Προκαθορισμένη διάταξη",
  "_layout_layout1": "Διάταξη 1"
});