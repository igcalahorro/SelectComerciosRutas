﻿/*global define*/
define({
  "_themeLabel": "高原主題",
  "_layout_default": "預設版面配置",
  "_layout_layout1": "版面配置 1"
});