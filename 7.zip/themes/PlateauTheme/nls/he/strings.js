﻿/*global define*/
define({
  "_themeLabel": "ערכת נושא מישור",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_layout1": "פריסה 1"
});