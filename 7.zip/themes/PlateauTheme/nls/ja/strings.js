﻿/*global define*/
define({
  "_themeLabel": "プラトー テーマ",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_layout1": "レイアウト 1"
});