﻿/*global define*/
define({
  "_themeLabel": "Ylätasanko-teema",
  "_layout_default": "Oletusasettelu",
  "_layout_layout1": "Asettelu 1"
});