﻿/*global define*/
define({
  "_themeLabel": "Plateau téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_layout1": "1. elrendezés"
});