﻿/*global define*/
define({
  "_themeLabel": "Chủ đề Cao nguyên",
  "_layout_default": "Bố cục mặc định",
  "_layout_layout1": "Bố cục 1"
});