﻿/*global define*/
define({
  "_themeLabel": "Tema Plateau",
  "_layout_default": "Layout Padrão",
  "_layout_layout1": "Layout 1"
});