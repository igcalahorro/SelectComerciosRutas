﻿/*global define*/
define({
  "_themeLabel": "Motyw Płaskowyż",
  "_layout_default": "Kompozycja domyślna",
  "_layout_layout1": "Kompozycja 1"
});