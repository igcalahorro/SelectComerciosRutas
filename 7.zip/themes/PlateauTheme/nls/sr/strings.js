﻿/*global define*/
define({
  "_themeLabel": "Tema platoa",
  "_layout_default": "Podrazumevani raspored",
  "_layout_layout1": "Raspored 1"
});