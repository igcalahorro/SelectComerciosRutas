﻿/*global define*/
define({
  "_themeLabel": "Tema Altiplà",
  "_layout_default": "Disseny per defecte",
  "_layout_layout1": "Disseny 1"
});