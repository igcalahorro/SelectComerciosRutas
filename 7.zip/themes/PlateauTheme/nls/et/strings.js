﻿/*global define*/
define({
  "_themeLabel": "Teema Platoo",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_layout1": "Paigutus 1"
});