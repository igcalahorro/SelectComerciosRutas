﻿/*global define*/
define({
  "_themeLabel": "Тема Плато",
  "_layout_default": "Компоновка по умолчанию",
  "_layout_layout1": "Компоновка 1"
});