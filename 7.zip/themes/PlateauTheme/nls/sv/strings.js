﻿/*global define*/
define({
  "_themeLabel": "Platåtema",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 1"
});