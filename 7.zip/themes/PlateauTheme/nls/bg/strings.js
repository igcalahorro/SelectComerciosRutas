﻿/*global define*/
define({
  "_themeLabel": "Тема на платото",
  "_layout_default": "Оформление по подразбиране",
  "_layout_layout1": "Оформление 1"
});