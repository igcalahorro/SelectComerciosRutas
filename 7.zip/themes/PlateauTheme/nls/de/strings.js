﻿/*global define*/
define({
  "_themeLabel": "Plateau-Design",
  "_layout_default": "Standard-Layout",
  "_layout_layout1": "Layout 1"
});