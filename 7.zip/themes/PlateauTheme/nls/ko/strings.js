﻿/*global define*/
define({
  "_themeLabel": "고원 테마",
  "_layout_default": "기본 레이아웃",
  "_layout_layout1": "레이아웃 1"
});