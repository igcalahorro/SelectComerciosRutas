﻿/*global define*/
define({
  "_themeLabel": "Plochý motiv",
  "_layout_default": "Výchozí rozvržení",
  "_layout_layout1": "Rozvržení 1"
});