﻿/*global define*/
define({
  "_themeLabel": "Plateauthema",
  "_layout_default": "Standaard lay-out",
  "_layout_layout1": "Lay-out 1"
});