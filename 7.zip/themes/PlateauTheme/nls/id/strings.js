﻿/*global define*/
define({
  "_themeLabel": "Tema Plateau",
  "_layout_default": "Tata Letak Default",
  "_layout_layout1": "Tata Letak 1"
});