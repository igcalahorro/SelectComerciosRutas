﻿/*global define*/
define({
  "_themeLabel": "ธีม plateau",
  "_layout_default": "โครงร่างตั้งต้น",
  "_layout_layout1": "โครงร่าง 1"
});